// إدارة البيانات المشتركة لمتجر Azab
class DataManager {
    constructor() {
        this.productsKey = 'azab_products';
        this.ordersKey = 'azab_orders';
        this.whatsappKey = 'azab_whatsapp';
        this.settingsKey = 'azab_settings';
    }

    // إدارة المنتجات
    getProducts() {
        try {
            return JSON.parse(localStorage.getItem(this.productsKey)) || [];
        } catch (error) {
            console.error('خطأ في قراءة المنتجات:', error);
            return [];
        }
    }

    saveProducts(products) {
        try {
            localStorage.setItem(this.productsKey, JSON.stringify(products));
            return true;
        } catch (error) {
            console.error('خطأ في حفظ المنتجات:', error);
            return false;
        }
    }

    addProduct(product) {
        const products = this.getProducts();
        product.id = Date.now(); // إضافة معرف فريد
        product.createdAt = new Date().toISOString();
        products.push(product);
        return this.saveProducts(products);
    }

    deleteProduct(productId) {
        const products = this.getProducts();
        const filteredProducts = products.filter(p => p.id !== productId);
        return this.saveProducts(filteredProducts);
    }

    // إدارة الطلبات
    getOrders() {
        try {
            return JSON.parse(localStorage.getItem(this.ordersKey)) || [];
        } catch (error) {
            console.error('خطأ في قراءة الطلبات:', error);
            return [];
        }
    }

    saveOrders(orders) {
        try {
            localStorage.setItem(this.ordersKey, JSON.stringify(orders));
            return true;
        } catch (error) {
            console.error('خطأ في حفظ الطلبات:', error);
            return false;
        }
    }

    addOrder(order) {
        const orders = this.getOrders();
        order.id = Date.now();
        order.createdAt = new Date().toISOString();
        order.status = 'جديد';
        orders.push(order);
        return this.saveOrders(orders);
    }

    // إدارة رقم الواتساب
    getWhatsAppNumber() {
        return localStorage.getItem(this.whatsappKey) || '201234567890';
    }

    setWhatsAppNumber(number) {
        localStorage.setItem(this.whatsappKey, number);
    }

    // إدارة الإعدادات العامة
    getSettings() {
        try {
            return JSON.parse(localStorage.getItem(this.settingsKey)) || {
                storeName: 'متجر عزب',
                storeDescription: 'أفضل المنتجات بأفضل الأسعار',
                currency: 'جنيه مصري'
            };
        } catch (error) {
            return {
                storeName: 'متجر عزب',
                storeDescription: 'أفضل المنتجات بأفضل الأسعار',
                currency: 'جنيه مصري'
            };
        }
    }

    saveSettings(settings) {
        try {
            localStorage.setItem(this.settingsKey, JSON.stringify(settings));
            return true;
        } catch (error) {
            console.error('خطأ في حفظ الإعدادات:', error);
            return false;
        }
    }

    // تنظيف البيانات
    clearAllData() {
        localStorage.removeItem(this.productsKey);
        localStorage.removeItem(this.ordersKey);
        localStorage.removeItem(this.whatsappKey);
        localStorage.removeItem(this.settingsKey);
    }

    // إحصائيات
    getStats() {
        const products = this.getProducts();
        const orders = this.getOrders();
        
        return {
            totalProducts: products.length,
            totalOrders: orders.length,
            newOrders: orders.filter(o => o.status === 'جديد').length,
            completedOrders: orders.filter(o => o.status === 'مكتمل').length
        };
    }
}

// إنشاء مثيل عام لإدارة البيانات
const dataManager = new DataManager();

