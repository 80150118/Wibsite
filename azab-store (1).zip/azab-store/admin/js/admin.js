// منطق لوحة تحكم المدير - Azab Store Admin
class AdminPanel {
    constructor() {
        this.currentEditingProduct = null;
        this.init();
    }

    init() {
        this.loadStats();
        this.loadProducts();
        this.loadOrders();
        this.loadSettings();
        this.setupEventListeners();
    }

    // تحميل الإحصائيات
    loadStats() {
        const stats = dataManager.getStats();
        
        document.getElementById('totalProducts').textContent = stats.totalProducts;
        document.getElementById('totalOrders').textContent = stats.totalOrders;
        document.getElementById('newOrders').textContent = stats.newOrders;
        document.getElementById('completedOrders').textContent = stats.completedOrders;
    }

    // تحميل المنتجات
    loadProducts() {
        const products = dataManager.getProducts();
        const productsContainer = document.getElementById('productsContainer');
        
        if (products.length === 0) {
            productsContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>لا توجد منتجات</h3>
                    <p>ابدأ بإضافة منتج جديد</p>
                </div>
            `;
            return;
        }

        productsContainer.innerHTML = products.map(product => `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}" class="product-image">
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-price">${product.price} جنيه مصري</div>
                    <p class="product-description">${product.desc}</p>
                    <div class="product-actions">
                        <button class="btn btn-warning btn-sm" onclick="adminPanel.editProduct(${product.id})">
                            <i class="fas fa-edit"></i>
                            تعديل
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="adminPanel.deleteProduct(${product.id})">
                            <i class="fas fa-trash"></i>
                            حذف
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // تحميل الطلبات
    loadOrders() {
        const orders = dataManager.getOrders();
        const ordersContainer = document.getElementById('ordersContainer');
        
        if (orders.length === 0) {
            ordersContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-shopping-cart"></i>
                    <h3>لا توجد طلبات</h3>
                    <p>ستظهر الطلبات هنا عند وصولها</p>
                </div>
            `;
            return;
        }

        // ترتيب الطلبات حسب التاريخ (الأحدث أولاً)
        orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        ordersContainer.innerHTML = orders.map(order => `
            <div class="order-card">
                <div class="order-header">
                    <div class="order-id">طلب #${order.id}</div>
                    <div class="order-date">${new Date(order.createdAt).toLocaleString('ar-EG')}</div>
                    <div class="order-status status-${order.status === 'جديد' ? 'new' : 'completed'}">
                        ${order.status}
                    </div>
                </div>
                <div class="order-details">
                    <div class="order-field">
                        <div class="field-label">المنتج:</div>
                        <div class="field-value">${order.product}</div>
                    </div>
                    <div class="order-field">
                        <div class="field-label">السعر:</div>
                        <div class="field-value">${order.productPrice} جنيه مصري</div>
                    </div>
                    <div class="order-field">
                        <div class="field-label">اسم العميل:</div>
                        <div class="field-value">${order.name}</div>
                    </div>
                    <div class="order-field">
                        <div class="field-label">الهاتف:</div>
                        <div class="field-value">
                            <a href="tel:${order.phone}">${order.phone}</a>
                        </div>
                    </div>
                    ${order.altPhone ? `
                    <div class="order-field">
                        <div class="field-label">هاتف آخر:</div>
                        <div class="field-value">
                            <a href="tel:${order.altPhone}">${order.altPhone}</a>
                        </div>
                    </div>
                    ` : ''}
                    <div class="order-field">
                        <div class="field-label">المحافظة:</div>
                        <div class="field-value">${order.city}</div>
                    </div>
                    <div class="order-field">
                        <div class="field-label">العنوان:</div>
                        <div class="field-value">${order.address}</div>
                    </div>
                </div>
                <div style="margin-top: 1rem;">
                    <button class="btn btn-success btn-sm" onclick="adminPanel.contactCustomer('${order.phone}', '${order.name}', '${order.product}')">
                        <i class="fab fa-whatsapp"></i>
                        تواصل عبر الواتساب
                    </button>
                    ${order.status === 'جديد' ? `
                    <button class="btn btn-primary btn-sm" onclick="adminPanel.markOrderCompleted(${order.id})">
                        <i class="fas fa-check"></i>
                        تم التنفيذ
                    </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    // تحميل الإعدادات
    loadSettings() {
        const settings = dataManager.getSettings();
        const whatsappNumber = dataManager.getWhatsAppNumber();

        document.getElementById('storeName').value = settings.storeName;
        document.getElementById('storeDescription').value = settings.storeDescription;
        document.getElementById('whatsappNumber').value = whatsappNumber;
    }

    // فتح نموذج إضافة منتج
    openAddProductModal() {
        this.currentEditingProduct = null;
        document.getElementById('modalTitle').textContent = 'إضافة منتج جديد';
        document.getElementById('productForm').reset();
        document.getElementById('imagePreview').style.display = 'none';
        document.getElementById('productModal').style.display = 'block';
        document.getElementById('productName').focus();
    }

    // تعديل منتج
    editProduct(productId) {
        const products = dataManager.getProducts();
        const product = products.find(p => p.id === productId);
        
        if (!product) {
            this.showMessage('لم يتم العثور على المنتج', 'error');
            return;
        }

        this.currentEditingProduct = product;
        document.getElementById('modalTitle').textContent = 'تعديل المنتج';
        document.getElementById('productName').value = product.name;
        document.getElementById('productPrice').value = product.price;
        document.getElementById('productDescription').value = product.desc;
        
        const imagePreview = document.getElementById('imagePreview');
        imagePreview.src = product.image;
        imagePreview.style.display = 'block';
        
        document.getElementById('productModal').style.display = 'block';
    }

    // حذف منتج
    deleteProduct(productId) {
        if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
            return;
        }

        if (dataManager.deleteProduct(productId)) {
            this.showMessage('تم حذف المنتج بنجاح');
            this.loadProducts();
            this.loadStats();
        } else {
            this.showMessage('حدث خطأ في حذف المنتج', 'error');
        }
    }

    // إغلاق نموذج المنتج
    closeProductModal() {
        document.getElementById('productModal').style.display = 'none';
        this.currentEditingProduct = null;
    }

    // حفظ المنتج
    saveProduct(event) {
        event.preventDefault();
        
        const name = document.getElementById('productName').value.trim();
        const price = document.getElementById('productPrice').value.trim();
        const desc = document.getElementById('productDescription').value.trim();
        const imageInput = document.getElementById('productImage');

        // التحقق من البيانات
        if (!name || !price || !desc) {
            this.showMessage('يرجى ملء جميع الحقول المطلوبة', 'error');
            return;
        }

        if (isNaN(price) || parseFloat(price) <= 0) {
            this.showMessage('يرجى إدخال سعر صحيح', 'error');
            return;
        }

        // التحقق من الصورة
        if (!this.currentEditingProduct && !imageInput.files.length) {
            this.showMessage('يرجى اختيار صورة للمنتج', 'error');
            return;
        }

        const processProduct = (imageData) => {
            const productData = {
                name,
                price: parseFloat(price),
                desc,
                image: imageData
            };

            let success = false;
            if (this.currentEditingProduct) {
                // تعديل منتج موجود
                const products = dataManager.getProducts();
                const index = products.findIndex(p => p.id === this.currentEditingProduct.id);
                if (index !== -1) {
                    products[index] = { ...this.currentEditingProduct, ...productData };
                    success = dataManager.saveProducts(products);
                }
            } else {
                // إضافة منتج جديد
                success = dataManager.addProduct(productData);
            }

            if (success) {
                this.showMessage(this.currentEditingProduct ? 'تم تعديل المنتج بنجاح' : 'تم إضافة المنتج بنجاح');
                this.closeProductModal();
                this.loadProducts();
                this.loadStats();
            } else {
                this.showMessage('حدث خطأ في حفظ المنتج', 'error');
            }
        };

        // معالجة الصورة
        if (imageInput.files.length > 0) {
            const reader = new FileReader();
            reader.onload = (e) => processProduct(e.target.result);
            reader.readAsDataURL(imageInput.files[0]);
        } else {
            // استخدام الصورة الحالية في حالة التعديل
            processProduct(this.currentEditingProduct.image);
        }
    }

    // معاينة الصورة
    previewImage(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const preview = document.getElementById('imagePreview');
                preview.src = e.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    // حفظ الإعدادات
    saveSettings(event) {
        event.preventDefault();
        
        const storeName = document.getElementById('storeName').value.trim();
        const storeDescription = document.getElementById('storeDescription').value.trim();
        const whatsappNumber = document.getElementById('whatsappNumber').value.trim();

        if (!storeName || !storeDescription || !whatsappNumber) {
            this.showMessage('يرجى ملء جميع الحقول', 'error');
            return;
        }

        // التحقق من رقم الواتساب
        if (!/^[0-9+\-\s()]{10,15}$/.test(whatsappNumber)) {
            this.showMessage('يرجى إدخال رقم واتساب صحيح', 'error');
            return;
        }

        const settings = {
            storeName,
            storeDescription,
            currency: 'جنيه مصري'
        };

        if (dataManager.saveSettings(settings) && dataManager.setWhatsAppNumber(whatsappNumber)) {
            this.showMessage('تم حفظ الإعدادات بنجاح');
        } else {
            this.showMessage('حدث خطأ في حفظ الإعدادات', 'error');
        }
    }

    // تواصل مع العميل
    contactCustomer(phone, name, product) {
        const message = `مرحباً ${name}،\n\nشكراً لك على طلب "${product}" من متجر عزب.\n\nسنتواصل معك قريباً لتأكيد الطلب وترتيب التوصيل.\n\nشكراً لثقتك بنا! 🙏`;
        const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
    }

    // تحديد الطلب كمكتمل
    markOrderCompleted(orderId) {
        const orders = dataManager.getOrders();
        const orderIndex = orders.findIndex(o => o.id === orderId);
        
        if (orderIndex !== -1) {
            orders[orderIndex].status = 'مكتمل';
            if (dataManager.saveOrders(orders)) {
                this.showMessage('تم تحديث حالة الطلب');
                this.loadOrders();
                this.loadStats();
            } else {
                this.showMessage('حدث خطأ في تحديث الطلب', 'error');
            }
        }
    }

    // الذهاب إلى المتجر
    goToStore() {
        window.open('../customer/index.html', '_blank');
    }

    // تسجيل الخروج
    logout() {
        if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
            sessionStorage.removeItem('admin_logged_in');
            window.location.href = 'login.html';
        }
    }

    // عرض رسالة
    showMessage(message, type = 'success') {
        // إزالة الرسائل السابقة
        const existingMessages = document.querySelectorAll('.success-message, .error-message, .info-message');
        existingMessages.forEach(msg => msg.remove());
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `${type}-message`;
        messageDiv.textContent = message;
        
        // إضافة الرسالة في أعلى الصفحة
        const main = document.querySelector('.admin-main .container');
        main.insertBefore(messageDiv, main.firstChild);
        
        // إزالة الرسالة بعد 5 ثوان
        setTimeout(() => {
            messageDiv.remove();
        }, 5000);
    }

    // إعداد مستمعي الأحداث
    setupEventListeners() {
        // إغلاق النموذج عند النقر على X
        document.querySelector('.close').addEventListener('click', () => {
            this.closeProductModal();
        });

        // إغلاق النموذج عند النقر خارجه
        window.addEventListener('click', (event) => {
            const modal = document.getElementById('productModal');
            if (event.target === modal) {
                this.closeProductModal();
            }
        });

        // إغلاق النموذج بمفتاح Escape
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                this.closeProductModal();
            }
        });

        // معاينة الصورة
        document.getElementById('productImage').addEventListener('change', (event) => {
            this.previewImage(event.target);
        });

        // إرسال نموذج المنتج
        document.getElementById('productForm').addEventListener('submit', (event) => {
            this.saveProduct(event);
        });

        // إرسال نموذج الإعدادات
        document.getElementById('settingsForm').addEventListener('submit', (event) => {
            this.saveSettings(event);
        });
    }
}

// تشغيل لوحة التحكم عند تحميل الصفحة
let adminPanel;
document.addEventListener('DOMContentLoaded', () => {
    adminPanel = new AdminPanel();
});

