// منطق متجر العملاء - Azab Store
class CustomerStore {
    constructor() {
        this.currentProduct = null;
        this.init();
    }

    init() {
        this.loadStoreInfo();
        this.loadProducts();
        this.setupEventListeners();
    }

    // تحميل معلومات المتجر
    loadStoreInfo() {
        const settings = dataManager.getSettings();
        const whatsappNumber = dataManager.getWhatsAppNumber();

        // تحديث اسم المتجر ووصفه
        document.getElementById('storeName').textContent = settings.storeName;
        document.getElementById('storeDescription').textContent = settings.storeDescription;
        
        // تحديث رقم الواتساب في الهيدر
        const whatsappLink = document.getElementById('whatsappContact');
        if (whatsappLink) {
            whatsappLink.href = `https://wa.me/${whatsappNumber}`;
            whatsappLink.textContent = this.formatPhoneNumber(whatsappNumber);
        }
    }

    // تحميل المنتجات
    loadProducts() {
        const products = dataManager.getProducts();
        const productsContainer = document.getElementById('productsContainer');
        
        if (products.length === 0) {
            productsContainer.innerHTML = `
                <div class="empty-state">
                    <h3>لا توجد منتجات متاحة حالياً</h3>
                    <p>يرجى المراجعة لاحقاً أو التواصل معنا عبر الواتساب</p>
                </div>
            `;
            return;
        }

        productsContainer.innerHTML = products.map(product => `
            <div class="product-card" data-product-id="${product.id}">
                <img src="${product.image}" alt="${product.name}" class="product-image" loading="lazy">
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-price">${product.price} جنيه مصري</div>
                    <p class="product-description">${product.desc}</p>
                    <button class="order-btn" onclick="customerStore.openOrderModal(${product.id})">
                        <span>🛒</span>
                        اطلب الآن
                    </button>
                </div>
            </div>
        `).join('');
    }

    // فتح نموذج الطلب
    openOrderModal(productId) {
        const products = dataManager.getProducts();
        this.currentProduct = products.find(p => p.id === productId);
        
        if (!this.currentProduct) {
            alert('عذراً، لم يتم العثور على المنتج');
            return;
        }

        // تحديث عنوان النموذج
        document.getElementById('modalProductName').textContent = this.currentProduct.name;
        
        // إظهار النموذج
        document.getElementById('orderModal').style.display = 'block';
        
        // التركيز على أول حقل
        document.getElementById('customerName').focus();
    }

    // إغلاق نموذج الطلب
    closeOrderModal() {
        document.getElementById('orderModal').style.display = 'none';
        this.currentProduct = null;
        this.clearForm();
    }

    // مسح النموذج
    clearForm() {
        document.getElementById('orderForm').reset();
        this.removeMessages();
    }

    // إزالة رسائل الخطأ والنجاح
    removeMessages() {
        const messages = document.querySelectorAll('.success-message, .error-message');
        messages.forEach(msg => msg.remove());
    }

    // عرض رسالة
    showMessage(message, type = 'success') {
        this.removeMessages();
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `${type}-message`;
        messageDiv.textContent = message;
        
        const form = document.getElementById('orderForm');
        form.insertBefore(messageDiv, form.firstChild);
        
        // إزالة الرسالة بعد 5 ثوان
        setTimeout(() => {
            messageDiv.remove();
        }, 5000);
    }

    // التحقق من صحة البيانات
    validateForm(formData) {
        const errors = [];

        if (!formData.customerName.trim()) {
            errors.push('يرجى إدخال الاسم');
        }

        if (!formData.customerPhone.trim()) {
            errors.push('يرجى إدخال رقم الهاتف');
        } else if (!/^[0-9+\-\s()]{10,15}$/.test(formData.customerPhone.trim())) {
            errors.push('يرجى إدخال رقم هاتف صحيح');
        }

        if (!formData.customerCity.trim()) {
            errors.push('يرجى اختيار المحافظة');
        }

        if (!formData.customerAddress.trim()) {
            errors.push('يرجى إدخال العنوان');
        }

        return errors;
    }

    // إرسال الطلب
    submitOrder(event) {
        event.preventDefault();
        
        if (!this.currentProduct) {
            this.showMessage('خطأ في تحديد المنتج', 'error');
            return;
        }

        // جمع بيانات النموذج
        const formData = {
            customerName: document.getElementById('customerName').value,
            customerPhone: document.getElementById('customerPhone').value,
            customerAltPhone: document.getElementById('customerAltPhone').value,
            customerCity: document.getElementById('customerCity').value,
            customerAddress: document.getElementById('customerAddress').value
        };

        // التحقق من صحة البيانات
        const errors = this.validateForm(formData);
        if (errors.length > 0) {
            this.showMessage(errors.join('، '), 'error');
            return;
        }

        // إنشاء الطلب
        const order = {
            product: this.currentProduct.name,
            productId: this.currentProduct.id,
            productPrice: this.currentProduct.price,
            name: formData.customerName,
            phone: formData.customerPhone,
            altPhone: formData.customerAltPhone,
            city: formData.customerCity,
            address: formData.customerAddress
        };

        // حفظ الطلب
        if (dataManager.addOrder(order)) {
            this.showMessage('تم إرسال طلبك بنجاح!');
            
            // إرسال الطلب عبر الواتساب
            setTimeout(() => {
                this.sendToWhatsApp(order);
                this.closeOrderModal();
            }, 2000);
        } else {
            this.showMessage('حدث خطأ في إرسال الطلب، يرجى المحاولة مرة أخرى', 'error');
        }
    }

    // إرسال الطلب عبر الواتساب
    sendToWhatsApp(order) {
        const whatsappNumber = dataManager.getWhatsAppNumber();
        const message = this.formatWhatsAppMessage(order);
        const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
        
        window.open(whatsappUrl, '_blank');
    }

    // تنسيق رسالة الواتساب
    formatWhatsAppMessage(order) {
        return `🛒 *طلب جديد من متجر عزب*

📦 *المنتج:* ${order.product}
💰 *السعر:* ${order.productPrice} جنيه مصري

👤 *بيانات العميل:*
• الاسم: ${order.name}
• الهاتف: ${order.phone}
${order.altPhone ? `• هاتف آخر: ${order.altPhone}` : ''}
• المحافظة: ${order.city}
• العنوان: ${order.address}

📅 *تاريخ الطلب:* ${new Date().toLocaleString('ar-EG')}

شكراً لك على ثقتك في متجرنا! 🙏`;
    }

    // تنسيق رقم الهاتف للعرض
    formatPhoneNumber(number) {
        // إزالة رمز الدولة إذا كان موجوداً
        let formatted = number.replace(/^\+?20/, '');
        
        // تنسيق الرقم
        if (formatted.length === 10) {
            return `${formatted.slice(0, 3)} ${formatted.slice(3, 6)} ${formatted.slice(6)}`;
        }
        
        return number;
    }

    // إعداد مستمعي الأحداث
    setupEventListeners() {
        // إغلاق النموذج عند النقر على X
        document.querySelector('.close').addEventListener('click', () => {
            this.closeOrderModal();
        });

        // إغلاق النموذج عند النقر خارجه
        window.addEventListener('click', (event) => {
            const modal = document.getElementById('orderModal');
            if (event.target === modal) {
                this.closeOrderModal();
            }
        });

        // إرسال النموذج
        document.getElementById('orderForm').addEventListener('submit', (event) => {
            this.submitOrder(event);
        });

        // إغلاق النموذج بمفتاح Escape
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                this.closeOrderModal();
            }
        });

        // تحديث المنتجات عند تغيير البيانات
        window.addEventListener('storage', (event) => {
            if (event.key === 'azab_products') {
                this.loadProducts();
            }
        });
    }
}

// تشغيل المتجر عند تحميل الصفحة
let customerStore;
document.addEventListener('DOMContentLoaded', () => {
    customerStore = new CustomerStore();
});

